package sammie.logindesign.com.material.SignUp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import sammie.logindesign.com.material.R;


public class SignUpActivityTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_two);
    }
}
