package sammie.logindesign.com.material.Profile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import sammie.logindesign.com.material.R;


public class ProfileOneActivity extends AppCompatActivity {

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_one);
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Profile Dashboard");
        setSupportActionBar(toolbar);
    }
}
